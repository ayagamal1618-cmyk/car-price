# 🚗 Car Price Predictor

A Streamlit web app that estimates a car's price from its make, year, engine
horsepower, vehicle size and transmission type, using a trained
scikit-learn `DecisionTreeRegressor`.

**Live demo:** <paste your Streamlit Cloud link here>

## Features / inputs
| Input | Type |
|---|---|
| Make | Dropdown (48 brands) |
| Year | Number |
| Engine HP | Number |
| Vehicle size | Compact / Midsize / Large |
| Transmission type | Automatic / Manual / Automated manual / Direct drive / Unknown |

## Project structure
```
car-price-app/
├── app.py                # Streamlit interface
├── car_price_model.pkl   # trained model
├── requirements.txt      # dependencies
└── README.md
```

## Run locally
```bash
git clone https://github.com/<your-username>/<your-repo>.git
cd <your-repo>
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
Open http://localhost:8501

## Deploy on Streamlit Community Cloud
1. Push this folder to a public GitHub repo.
2. Go to https://share.streamlit.io and sign in with GitHub.
3. Click **Create app**, choose the repo, branch `main`, main file `app.py`.
4. Click **Deploy**.

## Model details
- Algorithm: Decision Tree Regressor (scikit-learn 1.6.1)
- Features: year, engine hp, one-hot encoded make / vehicle size / transmission type
- Target: price (log-transformed; converted back with `expm1` in the app)

## Notes
- Predictions are estimates and depend on the training dataset.
- Keep `scikit-learn==1.6.1` in requirements: pickle files must be loaded with the
  same version they were saved with.

## License
MIT
